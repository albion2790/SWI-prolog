package Task1;

import java.util.ArrayList;
import java.util.List;
import java.util.function.UnaryOperator;

public class Task1a {

    public static void main(String[] args) {
        String fileName = "statistik-kes-denggi-di-negeri-pahang-bagi-tempoh-2014-2017.xlsx";
        String fileName2 = "statistik-kes-denggi-di-negeri-pahang-bagi-tempoh-2018-2019.xlsx";
        
        XlsxReader reader = new XlsxReader(fileName);
        List<ProjectWork> projectLst = reader.getAll();
        System.out.println("Test");
      //  projectLst.forEach(System.out::println);
        System.out.println("-------");
        // read the value from project work array last line add in y1~y5
         XlsxReader reader2 = new XlsxReader(fileName2);
         List<ProjectWork> projectLst2 = reader2.getAll(projectLst);
        System.out.println("Test");
        projectLst.forEach(System.out::println);
        System.out.println("-------");
    
     //   Sum(projectLst);
     
     
    }
    
  
    

}
