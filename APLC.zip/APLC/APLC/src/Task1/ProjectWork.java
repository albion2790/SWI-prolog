package Task1;

import java.util.List;

public class ProjectWork {

    private String area;
    private int year1, year2, year3, year4, year5;

    public ProjectWork(String area, int year1, int year2, int year3, int year4) {
        this.area = area;
        this.year1 = year1;
        this.year2 = year2;
        this.year3 = year3;
        this.year4 = year4;
       
    }
    
    
    
    public ProjectWork(String area, int year5) {
        this.area = area;
        this.year5 = year5;
    }

    public ProjectWork() {
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public int getYear5() {
        return year5;
    }

    public void setYear5(int year5) {
        this.year5 = year5;
    }

    public int getYear1() {
        return year1;
    }

    public void setYear1(int year1) {
        this.year1 = year1;
    }

    public int getYear2() {
        return year2;
    }

    public void setYear2(int year2) {
        this.year2 = year2;
    }

    public int getYear3() {
        return year3;
    }

    public void setYear3(int year3) {
        this.year3 = year3;
    }

    public int getYear4() {
        return year4;
    }

    public void setYear4(int year4) {
        this.year4 = year4;
    }

    @Override
    public String toString() {
        return "ProjectWork{" + "area=" + area + ", year1=" + year1 + ", year2=" + year2 + ", year3=" + year3 + ", year4=" + year4 + ", year5=" + year5 + '}';
    }

 

}
