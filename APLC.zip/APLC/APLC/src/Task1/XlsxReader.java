package Task1;

import java.util.List;
import java.io.FileInputStream;
import java.util.ArrayList;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class XlsxReader {
    //helpers
    private FileInputStream fis;
    private XSSFWorkbook wb;

    //target files
    private String targetFile;

    //constructor
    public XlsxReader(String targetFile) {
        this.targetFile = targetFile;
        try {
            fis = new FileInputStream(this.targetFile);
            wb = new XSSFWorkbook(fis);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<ProjectWork> getAll() {
        //define a list
        List<ProjectWork> lst = new ArrayList<>(); 
        //get sheet according to its number
        XSSFSheet sheet = wb.getSheetAt(0);
        //for
        for (Row row : sheet) {
            int rowNum = row.getRowNum();
         //   int sum1= 0;
            //skip row 0,1,2,3
            if (rowNum == 0 || rowNum == 1 || rowNum == 2 || rowNum == 3) continue;   
            lst.add(new ProjectWork( //collect into the ProjectWork Object
                    row.getCell(0).getStringCellValue(),
                    (int) row.getCell(1).getNumericCellValue(), //sum1 ++
                    (int) row.getCell(2).getNumericCellValue(), //sum2++
                    (int) row.getCell(3).getNumericCellValue(), //sum3++
                    (int) row.getCell(4).getNumericCellValue() //sum4++
                   
            )
            );
          //  int haiya = (int) row.getCell(2).getNumericCellValue(),
           // sum1=sum1+haiya; // (int) row.getCell(1).getNumericCellValue()  ++
            
        }
        // String list = lst.toString();
        System.out.println("Testing");
        return lst;
    }
    
    public List<ProjectWork> getAll( List<ProjectWork> lst2) {
        //define a list
        List<ProjectWork> lst = new ArrayList<>(); 
        //get sheet according to its number
        XSSFSheet sheet = wb.getSheetAt(0);
        //for
        for (Row row : sheet) {
            int rowNum = row.getRowNum();
         //   int sum1= 0;
            //skip row 0,1,2,3
            if (rowNum == 0 || rowNum == 1 || rowNum == 2 || rowNum == 3 ||rowNum ==4) continue;   
            lst2.add(new ProjectWork( //collect into the ProjectWork Object
                    row.getCell(1).getStringCellValue(),
                    (int) row.getCell(3).getNumericCellValue() //sum2++              
            )
            );
          //  int haiya = (int) row.getCell(2).getNumericCellValue(),
           // sum1=sum1+haiya; // (int) row.getCell(1).getNumericCellValue()  ++
            
        }
        // String list = lst.toString();
        System.out.println("Testing");
        return lst;
    }
    
    
    
}
