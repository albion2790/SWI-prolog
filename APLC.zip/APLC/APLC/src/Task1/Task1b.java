package Task1;

import java.util.List;
import java.util.stream.IntStream;

public class Task1b {

    public static void main(String[] args) {
       String fileName = "statistik-kes-denggi-di-negeri-pahang-bagi-tempoh-2014-2017.xlsx";
        XlsxReader reader = new XlsxReader(fileName);
        List<ProjectWork> projectLst = reader.getAll();
  //    System.out.println(sum(projectLst));
    //   int s = projectLst.stream().map(a->a.get(1)).mapToInt(e->int.valueOf(e)).sum().getAsInt();
       
    //     int p = projectLst.stream()
      //        .map(a->a.get(1))
       //       .mapToDouble(e->int.valueOf(e))
    //          .sum().getAsInt();
       
       
       
              // .flatMapToInt(Integer::intValue)
       //find the sum of the dengue cases per year
     System.out.println("The total of the year are:");
    System.out.println(q3(projectLst));
    }
    
  // public static  List<Integer> q3( List<ProjectWork> projectLst){
  //      return projectLst.stream().mapToInt(Integer::intValue).sum();
  // }
     public static IntStream q3( List<ProjectWork> projectLst){
        return projectLst.stream().flatMapToInt(IntStream::of).sum();
   }

     
     public static Function<List<ProjectWork>, ArrayList<SumOfYear>>
             getSumOfYear = lst -> 
     
}
